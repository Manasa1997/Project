package com.cg.ars;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ars.dao.ARSDao;

/**
 * Servlet implementation class ReserveServlet
 */
@WebServlet("/ReserveServlet")
public class ReserveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String srccity =request.getParameter("src");
		String destcity =request.getParameter("dest");
		String passenger =request.getParameter("passengers");
		int number=Integer.parseInt(passenger);
		String classtype =request.getParameter("class");
		
		ARSDao dao=new ARSDao();
		
		int b=dao.booking(number,classtype,srccity,destcity);
		System.out.println(b);
		if(b>0)
		{
			System.out.println("hello");
			response.sendRedirect("payment.jsp");
		}
	}

}
