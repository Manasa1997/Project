package com.cg.ars;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ars.dao.ARSDao;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String flightno =request.getParameter("flightno"); 
		String airlines=request.getParameter("airline"); 
		String depcity1 =request.getParameter("depcity"); 
		String arrcity1 =request.getParameter("arrcity");
		String depdate1 =request.getParameter("depdate");
		String ardate1 =request.getParameter("ardate");
		String dtime1 =request.getParameter("dtime");
		String atime1 =request.getParameter("atime");
		String firstseat1 =request.getParameter("firstseat");
		String firstseatfare1 =request.getParameter("firstseatfare");
		String busseat1=request.getParameter("busseat");
		String busfare1=request.getParameter("busfare");
		
		ARSDao dao=new ARSDao();
		int b=dao.addProduct(flightno, airlines, depcity1, arrcity1, depdate1, ardate1, dtime1, atime1, firstseat1, firstseatfare1, busseat1, busfare1);
		System.out.println(b);
		if(b>0)
		{
			out.println("Flight has been added successfully");
			response.sendRedirect("admin.jsp");
		}
		
		
	}

}
