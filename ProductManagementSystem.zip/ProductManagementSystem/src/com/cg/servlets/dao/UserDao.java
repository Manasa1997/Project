package com.cg.servlets.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDao {
	Connection con=null;
	PreparedStatement ps=null;

	public Connection getConnection(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:Xe";
	String user="system";
	String pass="Capgemini123";
	con=DriverManager.getConnection(url,user,pass);
	return con;

	}catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
	public boolean validateUser(String username,String password){
		try{
			con=getConnection();
			String sql="select * from user_details where password=?";
			ps=con.prepareStatement(sql);
			ps.setString(1, password);
			ResultSet rs=ps.executeQuery();
			return rs.next();
		}catch(Exception e)
		{
			
		}
		return false;
	}
	public int add(String username,String password,String mail,String mobile){
		con=getConnection();
		String sql="insert into user_details values(?,?,?,?)";
		try{
		ps=con.prepareStatement(sql);
		ps.setString(1,username);
		ps.setString(2, password);
		ps.setString(3, mail);
		ps.setString(4, mobile);
		int n=ps.executeUpdate();
		return n;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return 0;
		
		
		
	}	
	
	public int add1(String username,String new_pass,String confirm_pass){
	if(new_pass.equals(confirm_pass)){
		con=getConnection();
		String sql="update user_details set password=? where username=?";
		try{
		ps=con.prepareStatement(sql);
	    ps.setString(2,username);
		ps.setString(1, new_pass);
		//ps.setString(3, confirm_pass);
		int n=ps.executeUpdate();
		return n;
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
		return 0;
	}
	public int add2(String product_id,String product_name,String price,String model){
		con=getConnection();
		String sql="insert into products values(?,?,?,?)";
		try{
		ps=con.prepareStatement(sql);
		ps.setString(1,product_id);
		ps.setString(2,product_name);
		ps.setString(3, model);
		ps.setString(4,price);
		int n=ps.executeUpdate();
		return n;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return 0;
		
		
		
	}	
	public int edit(String model,String product_id){
		con=getConnection();
		String sql="update products set pmodel=?  where pid=?";
		try{
		ps=con.prepareStatement(sql);
		ps.setString(1,model);
		ps.setString(2,product_id);
		//ps.setString(3, model);
		//ps.setString(4,price);
		int n=ps.executeUpdate();
		return n;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return 0;
		
		
		
	}	
}


