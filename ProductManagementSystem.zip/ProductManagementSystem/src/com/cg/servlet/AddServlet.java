package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlets.dao.UserDao;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String product_id=request.getParameter("id");
		String product_name=request.getParameter("name");
		String price=request.getParameter("price");
		String model=request.getParameter("model");
		UserDao dao=new UserDao();
		int n=dao.add2(product_id,product_name, price,model);
		if(n>0){
			response.sendRedirect("home.jsp");
			//RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
			//rd.forward(request, response);
		}/*else{
			//response.sendRedirect("registration.jsp?emsg=something went wrong.try again");
			
			RequestDispatcher rd=request.getRequestDispatcher("registration.jsp?emsg=something went wrong.Try again");
			rd.include(request, response);
		}*/
		
		
	}

	}


