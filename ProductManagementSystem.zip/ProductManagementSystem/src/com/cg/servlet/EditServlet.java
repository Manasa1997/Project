package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlets.dao.UserDao;

/**
 * Servlet implementation class EditServlet
 */
@WebServlet("/EditServlet")
public class EditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String model=request.getParameter("model");
		String product_id=request.getParameter("id");
	//	String product_name=request.getParameter("name");
	//	String price=request.getParameter("price");
		
		UserDao dao=new UserDao();
		int n=dao.edit(model,product_id);
		if(n>0){
			out.println("Edited successfully");
			response.sendRedirect("view_all.jsp");
		
		
	}
	}
}
